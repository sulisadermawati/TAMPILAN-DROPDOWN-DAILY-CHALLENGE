
import tkinter as tk
from tkinter import ttk, messagebox
import random
import uuid
import datetime
import sys

from utils import (
    ensure_dirs, load_questions_for_package, normalize_correct_answer,
    pick_questions_with_fresh_priority, pick_daily_challenge_by_level,
    load_json, save_json, HISTORY_FILE, list_packages_from_soal
)

# ================= CONFIG =================
ensure_dirs()

QUESTIONS_PER_LEVEL = 8
SESSION_SECONDS = 75 * 60
DAILY_NUM = 5
DAILY_POINTS = {"easy": 1, "medium": 2, "hard": 3}

# ================= APP =================
class QuizApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Latihan Soal UTBK")
        try:
            self.state("zoomed")
        except Exception:
            pass

        self._style()

        self.container = ttk.Frame(self)
        self.container.pack(fill="both", expand=True)

        self.history = load_json(HISTORY_FILE, [])
        self.packages = list_packages_from_soal()

        # state
        self.questions = []
        self.idx = 0
        self.score = 0
        self.daily_score = 0
        self.daily_breakdown = {"easy": 0, "medium": 0, "hard": 0}
        self.is_daily = False
        self.showing_explanation = False

        self.timer_label = None
        self.remaining = SESSION_SECONDS
        self.timer_job = None

        self.current_package = None
        self.current_level = None

        self._home()

    # ================= STYLE =================
    def _style(self):
        s = ttk.Style()
        try:
            s.theme_use("clam")
        except Exception:
            pass

        bg = "#f9e7f4"
        text = "#4a044e"
        btn = "#f9bfe9"
        hover = "#fe5cb5"

        s.configure("TFrame", background=bg)
        s.configure("TLabel", background=bg, foreground=text)
        s.configure("Title.TLabel", font=("Segoe UI", 28, "bold"))
        s.configure("Subtitle.TLabel", font=("Segoe UI", 14))

        s.configure(
            "TButton",
            font=("Segoe UI", 16),
            padding=12,
            background=btn,
            foreground=text
        )
        s.map("TButton", background=[("active", hover)])

        s.configure(
            "Choice.TRadiobutton",
            background=bg,
            foreground=text,
            font=("Segoe UI", 16),
            padding=8
        )
        s.map("Choice.TRadiobutton", background=[("active", hover)])

    # ================= UTILS =================
    def clear(self):
        for w in self.container.winfo_children():
            w.destroy()

    # ================= TIMER =================
    def start_timer(self):
       
        if self.timer_job:
            try:
                self.after_cancel(self.timer_job)
            except Exception:
                pass
            self.timer_job = None

        self.remaining = SESSION_SECONDS
        self.timer_job = self.after(1000, self._tick)

    def _tick(self):
        try:
            m, s = divmod(self.remaining, 60)
            if self.timer_label and getattr(self.timer_label, "winfo_exists", lambda: False)():
                try:
                    self.timer_label.config(text=f"⏱ {m:02d}:{s:02d}")
                except tk.TclError:
                    pass
        except Exception:
            pass

        if self.remaining <= 0:
            if self.timer_job:
                try:
                    self.after_cancel(self.timer_job)
                except Exception:
                    pass
                self.timer_job = None
            try:
                messagebox.showinfo("Waktu Habis", "Sesi selesai")
            except Exception:
                pass
            self.finish()
            return

        self.remaining -= 1
        try:
            self.timer_job = self.after(1000, self._tick)
        except Exception:
            self.timer_job = None

    # ================= HOME =================
    def _home(self):
        if self.timer_job:
            try:
                self.after_cancel(self.timer_job)
            except Exception:
                pass
            self.timer_job = None

        self.clear()

        box = ttk.Frame(self.container)
        box.place(relx=0.5, rely=0.5, anchor="center")

        ttk.Label(box, text="Latihan Soal UTBK", style="Title.TLabel").pack(pady=20)
        ttk.Button(box, text="▶ Start", width=25, command=self._package_menu).pack(pady=10)
        ttk.Button(box, text="🔥 Daily Challenge", width=25, command=self._daily_menu).pack(pady=10)
        ttk.Button(box, text="📊 History", width=25, command=self._history).pack(pady=10)

    # ================= PACKAGE =================
    def _package_menu(self):
        self.clear()
        box = ttk.Frame(self.container)
        box.place(relx=0.5, rely=0.5, anchor="center")

        ttk.Label(box, text="Pilih Paket", style="Title.TLabel").pack(pady=20)
        if not self.packages:
            ttk.Label(box, text="Tidak ada paket tersedia", style="Subtitle.TLabel").pack(pady=10)
        for p in self.packages:
            ttk.Button(box, text=p, width=30,
                       command=lambda x=p: self._level_menu(x)).pack(pady=6)

        ttk.Button(box, text="⬅ Kembali", command=self._home).pack(pady=20)

    def _level_menu(self, package):
        self.clear()
        box = ttk.Frame(self.container)
        box.place(relx=0.5, rely=0.5, anchor="center")

        ttk.Label(box, text=f"Paket {package}", style="Title.TLabel").pack(pady=20)
        for lvl in ("easy", "medium", "hard"):
            ttk.Button(box, text=lvl.capitalize(), width=30,
                       command=lambda l=lvl: self.start_quiz(package, l)).pack(pady=6)

        ttk.Button(box, text="⬅ Kembali", command=self._package_menu).pack(pady=20)

    # ================= START QUIZ =================
    def start_quiz(self, package, level):
        pkg = (package or "").strip()
        lvl = (level or "").strip().lower()
        self.current_package = pkg
        self.current_level = lvl

        raw = load_questions_for_package(pkg)
        if not raw:
            messagebox.showinfo("Info", f"Soal tidak tersedia untuk paket: {package}")
            print(f"[DEBUG] start_quiz: package={pkg!r} raw_count=0")
            return

        db = normalize_correct_answer(raw) or []
        print(f"[DEBUG] start_quiz package={pkg!r} raw_count={len(raw)} normalized={len(db)} level={lvl}")

        self.questions = pick_questions_with_fresh_priority(
            db, QUESTIONS_PER_LEVEL, self.history, pkg, lvl
        ) or []

        print(f"[DEBUG] start_quiz: selected_count={len(self.questions)} (QUESTIONS_PER_LEVEL={QUESTIONS_PER_LEVEL})")

        if not self.questions:
            messagebox.showinfo("Info", f"Soal tidak tersedia untuk paket {package} pada level {level}")
            return

        self.idx = 0
        self.score = 0
        self.is_daily = False
        # start timer and show question
        self.start_timer()
        self.show_question()

    # ================= DAILY =================
    def _daily_menu(self):
        self.clear()
        box = ttk.Frame(self.container)
        box.place(relx=0.5, rely=0.5, anchor="center")

        ttk.Label(box, text="Daily Challenge", style="Title.TLabel").pack(pady=20)
        if not self.packages:
            ttk.Label(box, text="Tidak ada paket tersedia", style="Subtitle.TLabel").pack(pady=10)
        for p in self.packages:
            ttk.Button(box, text=p, width=30,
                       command=lambda x=p: self.start_daily(x)).pack(pady=6)

        ttk.Button(box, text="⬅ Kembali", command=self._home).pack(pady=20)

    def start_daily(self, package):
        """
        Daily challenge is a mix of levels with different point weights.
        Default distribution: hard=1, medium=2, easy=2 (total DAILY_NUM=5).
        If not enough questions in a level, fill from other levels.
        """
        pkg = (package or "").strip()
        self.current_package = pkg
        self.current_level = None

        raw = load_questions_for_package(pkg)
        if not raw:
            messagebox.showinfo("Info", f"Soal tidak tersedia untuk paket: {package}")
            print(f"[DEBUG] start_daily: package={pkg!r} raw_count=0")
            return

        db = normalize_correct_answer(raw) or []

        # desired distribution
        desired = {"hard": 1, "medium": 2, "easy": 2}
        selected = []

        # try deterministic per-level selection using pick_daily_challenge_by_level
        for lvl, cnt in desired.items():
            if cnt <= 0:
                continue
            part = pick_daily_challenge_by_level(db, pkg, level=lvl, count=cnt)
            if part:
                selected.extend(part)

        # if not enough selected, fill from remaining pool (any level)
        if len(selected) < DAILY_NUM:
            # collect remaining valid questions not already selected
            selected_ids = {q.get("id") for q in selected if q.get("id")}
            remaining_pool = [q for q in db if (q.get("question") or q.get("choices") or q.get("reading")) and q.get("id") not in selected_ids]
            if remaining_pool:
                random.shuffle(remaining_pool)
                need = DAILY_NUM - len(selected)
                selected.extend(remaining_pool[:need])

        # final fallback: if still not enough, allow reuse from db (deterministic seed)
        if len(selected) < DAILY_NUM:
            extra = pick_daily_challenge_by_level(db, pkg, level='all', count=DAILY_NUM - len(selected))
            if extra:
                selected.extend(extra)

        if not selected:
            messagebox.showinfo("Info", "Soal daily tidak tersedia")
            print(f"[DEBUG] start_daily: package={pkg!r} selected_count=0 after fallback")
            return

        # ensure exactly DAILY_NUM items (trim if more)
        if len(selected) > DAILY_NUM:
            selected = selected[:DAILY_NUM]

        self.questions = selected
        print(f"[DEBUG] start_daily package={pkg!r} total_db={len(db)} selected={len(self.questions)}")

        # reset daily scoring breakdown
        self.idx = 0
        self.daily_score = 0
        self.daily_breakdown = {"easy": 0, "medium": 0, "hard": 0}
        self.is_daily = True
        self.start_timer()
        self.show_question()

    # ================= QUESTION =================
    def show_question(self):
        self.showing_explanation = False
        self.clear()

        if not self.questions:
            messagebox.showinfo("Info", "Tidak ada soal untuk ditampilkan")
            self._home()
            return

        if not (0 <= self.idx < len(self.questions)):
            self.idx = 0

        top = ttk.Frame(self.container)
        top.pack(fill="x", pady=10)

        # create timer label before scheduling ticks update
        self.timer_label = ttk.Label(top, font=("Segoe UI", 14, "bold"))
        self.timer_label.pack(side="right", padx=22)

        # show initial remaining time immediately
        try:
            m, s = divmod(self.remaining, 60)
            self.timer_label.config(text=f"⏱ {m:02d}:{s:02d}")
        except Exception:
            pass

        card = ttk.Frame(self.container)
        card.place(relx=0.5, rely=0.5, anchor="center")

        q = self.questions[self.idx]

        ttk.Label(card, text=f"Soal {self.idx+1}/{len(self.questions)}",
                  style="Subtitle.TLabel").pack(pady=6)

        if q.get("reading"):
            ttk.Label(card, text=q["reading"], wraplength=1000,
                      justify="center").pack(pady=10)

        ttk.Label(card, text=q.get("question", "-"), wraplength=1000,
                  justify="center", font=("Segoe UI", 18)).pack(pady=12)

        self.answer_var = tk.IntVar(value=-1)
        self.radio = []

        for i, c in enumerate(q.get("choices", [])):
            rb = ttk.Radiobutton(
                card, text=c, variable=self.answer_var,
                value=i, style="Choice.TRadiobutton"
            )
            rb.pack(anchor="w", pady=4)
            self.radio.append(rb)

        self.feedback = ttk.Label(card, font=("Segoe UI", 16, "bold"))
        self.feedback.pack(pady=10)

        self.expl = ttk.Label(card, wraplength=1000, justify="center")
        self.expl.pack(pady=6)

        ttk.Button(card, text="Next ▶", command=self.next_step).pack(pady=26)
        ttk.Button(card, text="⬅ Kembali", command=self._home).pack()

    # ================= NEXT =================
    def next_step(self):
        if not self.questions:
            return

        q = self.questions[self.idx]

        if not self.showing_explanation:
            sel = self.answer_var.get()
            if sel == -1:
                messagebox.showwarning("Pilih", "Pilih jawaban dulu")
                return

            for rb in self.radio:
                rb.state(["disabled"])

            if sel == q.get("correct_answer"):
                if self.is_daily:
                    lvl = (q.get("level") or "easy").strip().lower()
                    pts = DAILY_POINTS.get(lvl, 1)
                    self.daily_score += pts
                    # accumulate breakdown by level
                    if lvl not in self.daily_breakdown:
                        self.daily_breakdown[lvl] = 0
                    self.daily_breakdown[lvl] += pts
                else:
                    self.score += 1
                self.feedback.config(text="✅ BENAR")
            else:
                self.feedback.config(text="❌ SALAH")

            self.expl.config(text=f"Pembahasan:\n{q.get('explanation','-')}")
            self.showing_explanation = True
            return

        if self.idx < len(self.questions) - 1:
            self.idx += 1
            self.show_question()
        else:
            self.finish()

    # ================= FINISH =================
    def finish(self):
        # cancel timer job if running
        if self.timer_job:
            try:
                self.after_cancel(self.timer_job)
            except Exception:
                pass
            self.timer_job = None

        all_ids = [q.get("id") for q in (self.questions or []) if q.get("id")]

        final_score = self.daily_score if self.is_daily else self.score

        result = {
            "id": str(uuid.uuid4()),
            "time": datetime.datetime.now().isoformat(),
            "score": final_score,
            "daily": self.daily_score if self.is_daily else None,
            "is_daily": bool(self.is_daily),
            "package": self.current_package,
            "level": self.current_level,
            "total_questions": len(self.questions) if self.questions else 0,
            "all_ids": all_ids
        }
        self.history.append(result)
        save_json(HISTORY_FILE, self.history)

        # show immediate result dialog with breakdown for daily
        if self.is_daily:
            breakdown_lines = []
            for lvl in ("easy", "medium", "hard"):
                pts = self.daily_breakdown.get(lvl, 0)
                breakdown_lines.append(f"{lvl.capitalize()}: {pts} pts")
            breakdown_text = "\n".join(breakdown_lines)
            messagebox.showinfo("Selesai - Daily Challenge", f"Skor kamu: {final_score}\n\nRincian poin:\n{breakdown_text}")
        else:
            messagebox.showinfo("Selesai", f"Skor kamu: {final_score}")

        self._home()

    # ================= HISTORY =================
    def _history(self):
        win = tk.Toplevel(self)
        win.title("History")
        win.geometry("700x400")

        cols = ("time", "package", "mode", "score")
        tree = ttk.Treeview(win, columns=cols, show="headings")
        tree.pack(fill="both", expand=True)

        tree.heading("time", text="Waktu")
        tree.heading("package", text="Paket")
        tree.heading("mode", text="Mode")
        tree.heading("score", text="Skor")

        for h in reversed(self.history[-30:]):
            time = h.get("time", "-")
            pkg = h.get("package") or "-"
            mode = "Daily" if h.get("is_daily") else "Regular"
            score = h.get("score", 0)
            tree.insert("", "end", values=(time, pkg, mode, score))

# ================= MAIN =================
if __name__ == "__main__":
    try:
        QuizApp().mainloop()
    except Exception as e:
        print("Error saat menjalankan aplikasi:", e, file=sys.stderr)

